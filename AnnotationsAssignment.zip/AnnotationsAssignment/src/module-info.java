/**
 * 
 */
/**
 * @author buddredd
 *
 */
module AnnotationsAssignment {
}